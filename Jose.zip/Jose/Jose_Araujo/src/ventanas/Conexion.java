package ventanas;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Conexion {

    static String login = "ute2016";
    static String pass = "ute2016";
    static String url = "jdbc:mysql://107.180.58.67:3306/Asenut";
//    static String login = "root";
//    static String pass = "1234";
//    static String url = "jdbc:mysql://127.0.0.1:3306/asenut";
    static Connection link;

    public static Connection Conectar() {
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
            link=DriverManager.getConnection(url, login, pass);
            if (link != null) {
                //JOptionPane.showMessageDialog(null, "Bien Hecho!!");
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showConfirmDialog(null, e);
        }
        return link;
    }

    public static void Close() {
        try {
            link.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        Conectar();
        Interfaz in = new Interfaz();
        in.show();
    }
}
