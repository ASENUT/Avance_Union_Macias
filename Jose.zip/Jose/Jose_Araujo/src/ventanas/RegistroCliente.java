package ventanas;

import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.*;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class RegistroCliente extends javax.swing.JFrame {

    public RegistroCliente() {
        initComponents();
        this.setLocationRelativeTo(null);

        //VALIDAR CAMPOS
        SoloNumeros(txtCedulaCliente);
        SoloLetras(txtNombreCliente);
        SoloLetras(txtApellidosCliente);
        SoloNumeros(txtTelefonoCliente);
        SoloNumeros(txtCelularCliente);
        //SoloNumeros(cbxEstadoCivil);

        //Tamaño campos de texto
        LimitaCaracteres(txtCedulaCliente, 13);
        LimitaCaracteres(txtNombreCliente, 15);
        LimitaCaracteres(txtApellidosCliente, 15);
        LimitaCaracteres(txtTelefonoCliente, 9);
        LimitaCaracteres(txtCelularCliente, 10);
        LimitaCaracteres(txtEmailCliente, 20);
        LimitaCaracteres(txtFacebookCliente, 30);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cbxSexo = new javax.swing.JComboBox();
        cbxEstadoCivil = new javax.swing.JComboBox();
        dchoFecha = new com.toedter.calendar.JDateChooser();
        txtNombreCliente = new javax.swing.JTextField();
        txtTelefonoCliente = new javax.swing.JTextField();
        txtCelularCliente = new javax.swing.JTextField();
        txtEmailCliente = new javax.swing.JTextField();
        jsfNumHijos = new com.toedter.components.JSpinField();
        jLabel79 = new javax.swing.JLabel();
        txtFacebookCliente = new javax.swing.JTextField();
        txtApellidosCliente = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtCedulaCliente = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jmenNuevo = new javax.swing.JMenu();
        jmenGuardar = new javax.swing.JMenu();
        jmenRegresar = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("RegistroCliente"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Genero:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 50, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Nombres:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 110, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Estado Civil:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, 70, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("# Hijos:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 50, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Fecha de Nacimineto:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Teléfono:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 60, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Celular:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 50, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("E-mail:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 40, 30));

        cbxSexo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mujer", "Hombre", "Otros" }));
        getContentPane().add(cbxSexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 80, 30));

        cbxEstadoCivil.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Soltero/a", "Unión Libre", "Casado/a", "Divorciado/a", "Viudo/a" }));
        getContentPane().add(cbxEstadoCivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 80, 30));
        getContentPane().add(dchoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 150, 25));
        getContentPane().add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 150, 25));
        getContentPane().add(txtTelefonoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 150, 25));
        getContentPane().add(txtCelularCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 150, 25));
        getContentPane().add(txtEmailCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 150, 25));
        getContentPane().add(jsfNumHijos, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, 40, 30));

        jLabel79.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel79.setText("Facebook:");
        getContentPane().add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));
        getContentPane().add(txtFacebookCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 150, 25));
        getContentPane().add(txtApellidosCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 150, 25));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Apellidos:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Cedula:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));
        getContentPane().add(txtCedulaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 150, 25));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel13.setPreferredSize(new java.awt.Dimension(650, 427));
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 550, 440));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jmenNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/New.png"))); // NOI18N
        jmenNuevo.setText("Nuevo");
        jmenNuevo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmenNuevoMouseClicked(evt);
            }
        });
        jMenuBar1.add(jmenNuevo);

        jmenGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        jmenGuardar.setText("Guardar");
        jmenGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmenGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(jmenGuardar);

        jmenRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jmenRegresar.setText("Regresar");
        jmenRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmenRegresarMouseClicked(evt);
            }
        });
        jMenuBar1.add(jmenRegresar);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jmenRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmenRegresarMouseClicked
        // TODO add your handling code here:
        DatosGenerales dg = new DatosGenerales();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jmenRegresarMouseClicked

    private void jmenGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmenGuardarMouseClicked

        PreparedStatement cmd;
        ResultSet rs;
        Conexion.Conectar();
        
        if (txtCedulaCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese cedula", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtNombreCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese Nombre", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtApellidosCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese Apellido", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtTelefonoCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese Telefono Convencional", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtCelularCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese Telefono Celular", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtEmailCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese E-mail", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (txtFacebookCliente.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese Facebook", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (dchoFecha.getDate() == null) {

            JOptionPane.showMessageDialog(null, "Ingrese Fecha", "Error!", JOptionPane.ERROR_MESSAGE);

        } else if (JOptionPane.showConfirmDialog(null, "Guardar datos", "Confirmar", 1) == 0) {

            //ingresos
            String CEDULA = "'" + txtCedulaCliente.getText() + "'";
            String COD_ESTADO = "'" + (cbxEstadoCivil.getSelectedIndex() + 1) + "'";
            String NOM_PAC = "'" + txtNombreCliente.getText() + "'";
            String APE_PAC = "'" + txtApellidosCliente.getText() + "'";
            String TELF_CONVEN = "'" + txtTelefonoCliente.getText() + "'";
            String TELF_MOVIL = "'" + txtCelularCliente.getText() + "'";

            //fecha
            int anio = dchoFecha.getCalendar().get(Calendar.YEAR);
            int mes = dchoFecha.getCalendar().get(Calendar.MONTH);
            String dia = "";
            if (dchoFecha.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
                dia = "0" + dchoFecha.getCalendar().get(Calendar.DAY_OF_MONTH);
            } else {
                dia = String.valueOf(dchoFecha.getCalendar().get(Calendar.DAY_OF_MONTH));
            }
            String fecha1 = anio + "-" + (mes + 1) + "-" + dia;
            String FECH_NACI = "'" + fecha1 + "'";

            String CORREO_PACI = "'" + txtEmailCliente.getText() + "'";
            String FACEBOOK = "'" + txtFacebookCliente.getText() + "'";
            String GEN_PACI = "'" + cbxSexo.getSelectedItem() + "'";
            String NUM_HIJOS = "'" + jsfNumHijos.getValue() + "'";

            try {

                rs = ventanas.Conexion.link.createStatement().executeQuery(" SELECT * FROM PACIENTE WHERE CEDULA = " + CEDULA + " ");
                int count = 0;
                while (rs.next()) {
                    count++;
                }
                if (count > 0) {

                    JOptionPane.showMessageDialog(null, "El registro del cliente ya existe");

                } else {

                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PACIENTE VALUES ( " + CEDULA + "," + COD_ESTADO + "," + NOM_PAC + "," + APE_PAC + "," + TELF_CONVEN + "," + TELF_MOVIL + "," + FECH_NACI + "," + CORREO_PACI + "," + FACEBOOK + "," + GEN_PACI + "," + NUM_HIJOS + " ) ");
                    cmd.execute();
                    JOptionPane.showMessageDialog(null, "INGRESO EXITOSO!");
                    Limpiar();

                }

            } catch (SQLException ex) {

                JOptionPane.showMessageDialog(null, ex);
            }

        }

    }//GEN-LAST:event_jmenGuardarMouseClicked

    private void jmenNuevoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmenNuevoMouseClicked

        this.hide();
        RegistroCliente rg = new RegistroCliente();
        rg.show();

    }//GEN-LAST:event_jmenNuevoMouseClicked

    public void SoloLetras(JTextField a) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (Character.isDigit(c)) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    //metodo consume() hace que ese tecleo no sirva
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS");

                    //no tomo encuenta caracteres especiales por evitar conflictos en la BDD
                } else if ((int) ke.getKeyChar() > 32 && (int) ke.getKeyChar() <= 47
                        || (int) ke.getKeyChar() >= 58 && (int) ke.getKeyChar() <= 64
                        || (int) ke.getKeyChar() >= 91 && (int) ke.getKeyChar() <= 96
                        || (int) ke.getKeyChar() >= 123 && (int) ke.getKeyChar() <= 225) {

                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS!");
                }
            }

            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public void SoloNumeros(JTextField a) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (Character.isLetter(c)) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");

                } else if ((int) ke.getKeyChar() > 32 && (int) ke.getKeyChar() <= 47
                        || (int) ke.getKeyChar() >= 58 && (int) ke.getKeyChar() <= 64
                        || (int) ke.getKeyChar() >= 91 && (int) ke.getKeyChar() <= 96
                        || (int) ke.getKeyChar() >= 123 && (int) ke.getKeyChar() <= 225) {

                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE NUMEROS");
                }
            }

            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public void LimitaCaracteres(JTextField a, int lim) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (a.getText().length() == lim) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();

                }
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public void Limpiar() {

        //limpio cada una de las cajas de texto
        txtCedulaCliente.setText("");
        txtNombreCliente.setText("");
        txtApellidosCliente.setText("");
        txtEmailCliente.setText("");
        txtFacebookCliente.setText("");
        txtTelefonoCliente.setText("");
        txtCelularCliente.setText("");
        dchoFecha.setDateFormatString("");
        cbxEstadoCivil.setSelectedIndex(0);
        cbxSexo.setSelectedItem(0);
        jsfNumHijos.setValue(0);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cbxEstadoCivil;
    private javax.swing.JComboBox cbxSexo;
    private com.toedter.calendar.JDateChooser dchoFecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jmenGuardar;
    private javax.swing.JMenu jmenNuevo;
    private javax.swing.JMenu jmenRegresar;
    private com.toedter.components.JSpinField jsfNumHijos;
    private javax.swing.JTextField txtApellidosCliente;
    private javax.swing.JTextField txtCedulaCliente;
    private javax.swing.JTextField txtCelularCliente;
    private javax.swing.JTextField txtEmailCliente;
    private javax.swing.JTextField txtFacebookCliente;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtTelefonoCliente;
    // End of variables declaration//GEN-END:variables
}
