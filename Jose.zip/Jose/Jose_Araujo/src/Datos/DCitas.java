/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author MASTER
 */
public class DCitas {
    public String HoraCita;
    public String FechaCita;
    public String Cliente;
    public String TipoCita;

    public DCitas(){
        
    }
    public DCitas(String HoraCita, String FechaCita, String Cliente, String TipoCita) {
        this.HoraCita = HoraCita;
        this.FechaCita = FechaCita;
        this.Cliente = Cliente;
        this.TipoCita = TipoCita;
    }

    
    public String getHoraCita() {
        return HoraCita;
    }

    public void setHoraCita(String HoraCita) {
        this.HoraCita = HoraCita;
    }

    public String getFechaCita() {
        return FechaCita;
    }

    public void setFechaCita(String FechaCita) {
        this.FechaCita = FechaCita;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }

    public String getTipoCita() {
        return TipoCita;
    }

    public void setTipoCita(String TipoCita) {
        this.TipoCita = TipoCita;
    }
    
    
}
